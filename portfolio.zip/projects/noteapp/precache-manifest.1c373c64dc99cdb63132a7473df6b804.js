self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "09b1247b2a2d2d94d4c3e96b49b99efa",
    "url": "/projects/noteapp/index.html"
  },
  {
    "revision": "6b35d277b763dc87c7d3",
    "url": "/projects/noteapp/static/css/main.f44b5181.chunk.css"
  },
  {
    "revision": "01cfd4a5330197582c23",
    "url": "/projects/noteapp/static/js/2.a449ee58.chunk.js"
  },
  {
    "revision": "65d71c29c23ed61c2356dcee6d9321b3",
    "url": "/projects/noteapp/static/js/2.a449ee58.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6b35d277b763dc87c7d3",
    "url": "/projects/noteapp/static/js/main.c9ae32e8.chunk.js"
  },
  {
    "revision": "f55f1821cfa205c78355",
    "url": "/projects/noteapp/static/js/runtime-main.d1f0d5b7.js"
  }
]);